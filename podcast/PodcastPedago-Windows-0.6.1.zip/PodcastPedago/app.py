"""Interface locale du générateur PDF → podcast pédagogique."""
import argparse
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import queue
import re
import secrets
import signal
import threading
import time
from urllib.parse import parse_qs, unquote, urlsplit
import uuid
import webbrowser
import zipfile

from llm import Ollama, Cancelled, endpoint_parts, models
import pipeline as pipeline_module
from pipeline import Pipeline, STEPS
from storage import defaults, fingerprint, invalidate, read, write
import audio_export
import voice_legacy
import source_review
import source_decisions
import review_flow
import pdf_reread
from issues import ReviewRequired, DownloadConsentRequired, SourceIssue
from review_queue import Reviews

ROOT = Path(__file__).resolve().parent
APP_VERSION = '0.6.1'


def settings(value):
    if not isinstance(value,dict):
        raise ValueError('Paramètres invalides.')
    result = defaults()
    result.update({k:v for k,v in value.items() if k in result})
    for key in ('endpoint','model','audience'):
        if not isinstance(result[key],str) or not result[key].strip() or len(result[key])>2000:
            raise ValueError('Champ invalide : '+key)
        result[key] = result[key].strip()
    endpoint_parts(result['endpoint'])
    if type(result['minutes']) is not int or not 3<=result['minutes']<=180:
        raise ValueError('Choisissez une durée entre 3 et 180 minutes.')
    if type(result['num_ctx']) is not int or not 8192<=result['num_ctx']<=131072:
        raise ValueError('Le contexte doit être compris entre 8192 et 131072 tokens.')
    if type(result['temperature']) not in (float,int) or not 0<=result['temperature']<=1:
        raise ValueError('Température invalide.')
    people = result['speakers']
    if not isinstance(people,list) or not 2<=len(people)<=3 or any(not isinstance(p,str) or not p.strip() or len(p)>40 or '\n' in p or '\r' in p for p in people):
        raise ValueError('Indiquez deux ou trois intervenants, séparés par des virgules.')
    result['speakers'] = [p.strip() for p in people]
    if len(set(result['speakers']))!=len(people):
        raise ValueError('Les noms des intervenants doivent être différents.')
    return result


class Busy(ValueError):
    pass


class App:
    def __init__(self, directory, client_factory=Ollama):
        self.directory = Path(directory).resolve()
        self.projects = self.directory/'projets';self.projects.mkdir(parents=True,exist_ok=True)
        self.token = secrets.token_urlsafe(32)
        self.lock = threading.RLock()
        self.pending = queue.Queue()
        self.stop = threading.Event()
        self.cancels = {}
        self.task_errors = {}
        self.active = None
        self.runtime = {'version':APP_VERSION,'page_sources':getattr(pipeline_module,'SOURCE_PAGE_MODE','legacy'),
                        'review_ui':'paged-v1',
                        'summary_quality':getattr(pipeline_module,'SUMMARY_QUALITY_MODE','legacy'),
                        'editorial_mode':getattr(pipeline_module,'EDITORIAL_MODE','legacy'),
                        'app_dir':str(ROOT),'pid':os.getpid()}
        self.client_factory = client_factory
        for path in self.projects.glob('*/tache.json'):
            task = read(path)
            if task['state'] in ('running','queued'):
                task.update(state='interrupted',message='Interrompu à la fermeture. Les étapes terminées sont conservées.')
                write(path,task)
        self.worker = threading.Thread(target=self._loop,daemon=True);self.worker.start()

    def project(self, identifier):
        if not re.fullmatch('[a-f0-9]{32}',identifier):
            raise ValueError('Identifiant de projet invalide.')
        folder = self.projects/identifier
        if not (folder/'projet.json').is_file():
            raise FileNotFoundError('Projet introuvable.')
        return folder

    def idle(self, folder):
        path = folder/'tache.json'
        task = self.task_errors.get(folder.name) or (read(path) if path.exists() else {})
        if task.get('state') in ('queued','running'):
            raise Busy('Un traitement est en cours pour ce projet. Attendez sa fin ou annulez-le.')

    def create(self, body):
        if not isinstance(body.get('name'),str) or not body['name'].strip():
            raise ValueError('Donnez un nom au projet.')
        folder = self.projects/uuid.uuid4().hex
        folder.mkdir();(folder/'sources').mkdir()
        write(folder/'projet.json',{'id':folder.name,'name':body['name'].strip()[:150],
              'created':time.time(),'settings':settings(body.get('settings',{})),'pdfs':[],
              'audio_source_mode':'provided' if body.get('audio_only') is True else 'project'})
        return {'id':folder.name}

    def summary(self, folder):
        meta = read(folder/'projet.json')
        completed = [n for n in range(1,10) if (folder/'etapes'/f'{n:02}.json').exists()]
        source_data=read(folder/'etapes/02.json')['data'] if 2 in completed else {}
        review_store=Reviews(folder);pending_reviews=review_store.pending();review_data=review_store.data()
        deferred_reviews=[i for i in review_data['items'] if i['status']=='deferred']
        for item in pending_reviews+deferred_reviews:item['label']=review_flow.reason_label(item)
        source_diagnostic=source_review.diagnostic(source_data)
        needs_upgrade=2 in completed and source_data.get('quality_version')!='source-review-v5'
        task = self.task_errors.get(folder.name) or (read(folder/'tache.json') if (folder/'tache.json').exists() else None)
        if task and task['state']=='error' and task.get('app_version')!=APP_VERSION:
            task={**task,'message':'Ancien échec enregistré — cliquez sur Continuer pour reprendre avec la version '+APP_VERSION,
                  'from_previous_version':True}
            if source_diagnostic['empty']:task['message']='Ancien échec — réexaminer l’étape 2 avec le nouveau contrôle des citations'
        exports = [p.name for p in (folder/'exports').glob('podcast.*') if p.suffix in ('.md','.txt','.json')]
        if needs_upgrade or source_diagnostic['empty'] or pending_reviews:exports=[]
        parts = [p.name for p in sorted((folder/'etapes'/'parties').glob('*.md'))
                 if re.fullmatch(r'0[1-9]-[A-Za-z0-9-]+\.md',p.name) and p.with_suffix('.json').exists()]
        flow=review_flow.overview(source_data,completed,task,pending_reviews,deferred_reviews,len(parts),
            [i['step'] for i in review_data['items'] if i['status']=='retry'])
        flow['step_saved_parts']=sum(name.startswith(f'{flow["current_step"]:02}-') for name in parts)
        return {**meta,'completed':completed,'task':task,'exports':exports,'parts':parts,
                'pdf_reread_available':pdf_reread.available(),
                'pdf_readings':[p.name for p in (folder/'lectures_pdf').glob('*.md') if p.with_suffix('.json').exists()],
                'reviews':pending_reviews,'review_history':len(review_data['decisions']),
                'deferred_reviews':deferred_reviews,
                'flow':flow,
                'incomplete_source_parts':[d['id']+'-P'+str(p['number']) for d in source_data.get('documents',[]) for p in d['parts'] if p.get('incomplete_extraction')],
                'audio':self.audio_summary(folder,meta,needs_upgrade or source_diagnostic['empty'] or bool(pending_reviews)),
                'source_diagnostic':source_diagnostic,
                'needs_source_upgrade':needs_upgrade,
                'next_step':min([next((n for n in range(1,10) if n not in completed),10)]+
                    [i['step'] for i in review_data['items'] if i['status']=='retry'])}

    def defer_reviews(self,folder,body):
        with self.lock:
            self.idle(folder)
            if not (folder/'etapes/02.json').exists():raise ValueError('Terminez l’étape 2 avant de choisir les passages à laisser de côté.')
            source=read(folder/'etapes/02.json')['data']
            if source.get('quality_version')!=pipeline_module.SUMMARY_QUALITY_MODE:raise ValueError('Réexaminez les sources avec les contrôles actuels avant de poursuivre.')
            store=Reviews(folder);pending=store.pending();eligible=review_flow.eligible_reviews(source,pending)
            identities=body.get('ids');resume=body.get('continue',False)
            if not isinstance(identities,list) or not identities or len(identities)>10000 or any(not isinstance(i,str) for i in identities):raise ValueError('Choisissez les passages à mettre de côté.')
            if len(set(identities))!=len(identities) or not set(identities)<={i['id'] for i in eligible}:raise ValueError('Seuls les candidats non retenus à l’étape 2 peuvent être laissés de côté. Une idée utilisée ou un extrait non lu doit être vérifié.')
            if type(resume) is not bool:raise ValueError('Option de poursuite invalide.')
            if resume:
                if set(identities)!={i['id'] for i in pending}:raise ValueError('D’autres vérifications restent nécessaires avant de continuer. Actualisez la page.')
                if not any(p['ideas'] for d in source['documents'] for p in d['parts']):raise ValueError('Aucune idée retenue ne permet de poursuivre le podcast.')
            count=store.defer(identities)
            self.review_status(folder,f'{count} passage(s) mis de côté. Ils restent consultables et ne sont pas utilisés dans le podcast.')
            first=min([next((n for n in range(3,10) if not (folder/'etapes'/f'{n:02}.json').exists()),10)]+
                [i['step'] for i in store.data()['items'] if i['status']=='retry'])
            task=self.enqueue(folder,{'first':first,'until':9}) if resume and first<=9 else None
            return {'deferred':count,'task':task}

    def reopen_review(self,folder,body):
        with self.lock:
            self.idle(folder);item=Reviews(folder).reopen(body.get('id'))
            self.review_status(folder,'Vérification reprise : ce passage reste à confirmer avant de continuer.')
            return {'saved':True,'id':item['id']}

    def enqueue_reread(self,folder,body):
        with self.lock:
            self.idle(folder)
            item=next((i for i in Reviews(folder).pending() if i['id']==body.get('id')),None)
            if item is None:raise ValueError('Vérification absente.')
            if not pdf_reread.available():raise ValueError('Docling local n’est pas préparé. Aucun téléchargement automatique ; vérifiez la page du PDF.')
            source=item['source'];match=re.fullmatch(r'PDF([1-9]\d*)',source.get('document',''))
            if not match or not source.get('pages'):raise ValueError('Page source inconnue.')
            meta=read(folder/'projet.json');index=int(match[1])-1
            if index>=len(meta['pdfs']):raise ValueError('PDF inconnu.')
            page=min(source['pages'])
            task={'id':uuid.uuid4().hex,'kind':'pdf_reading','document':source['document'],'page':page,
                'queued_at':time.time(),'state':'queued','message':'Relecture locale en attente','error':None,'app_version':APP_VERSION}
            cancel=threading.Event();self.cancels[task['id']]=cancel
            write(folder/'tache.json',task);self.task_errors.pop(folder.name,None)
            self.pending.put((folder,task,cancel));return task

    def resolve_review(self,folder,body):
        with self.lock:
            self.idle(folder)
            result=source_decisions.resolve(folder,body,
                lambda path:self.preserve_summaries(path,read(path/'projet.json')),pipeline_module.part_markdown)
            self.review_status(folder,'Nouvelle tentative demandée : cliquez sur Continuer.' if body.get('action')=='retry'
                else 'Décision enregistrée : cliquez sur Continuer après les vérifications restantes.')
            return result

    def review_status(self,folder,message):
        path=folder/'tache.json'
        task=read(path) if path.exists() else {'id':uuid.uuid4().hex,'app_version':APP_VERSION}
        task.update(state='needs_review' if Reviews(folder).pending() else 'done',message=message,error=None)
        write(path,task)

    def flag_source(self,folder,body):
        with self.lock:
            self.idle(folder);data=read(folder/'etapes/02.json')['data']
            idea=next((i for d in data['documents'] for p in d['parts'] for i in p['ideas']+p.get('excluded_ideas',[]) if i['id']==body.get('id')),None)
            if idea is None:raise ValueError('Idée source inconnue.')
            item=Reviews(folder).record(2,'Source-'+idea['id'],idea,SourceIssue('Vérification demandée par l’utilisateur : relire l’idée et ses preuves avant de poursuivre.'),force=True)
            self.review_status(folder,'Une idée a été ajoutée aux vérifications regroupées.')
            return item

    def audio_input(self,folder,meta):
        mode=meta.get('audio_source_mode','project')
        path=folder/'lecture/dialogue.json' if mode=='provided' else folder/'exports/podcast.json'
        value=read(path) if path.exists() else None
        speakers=value.get('speakers',meta['settings']['speakers']) if value and mode=='provided' else meta['settings']['speakers']
        return value,speakers,mode

    def audio_summary(self,folder,meta,needs_upgrade=False):
        config=audio_export.settings(meta.get('audio_settings',{}))
        final,speakers,mode=self.audio_input(folder,meta)
        try:audio_export.encoder();encoder_ready=True
        except ValueError:encoder_ready=False
        result={'settings':config,'speakers':speakers,'source_mode':mode,'script_ready':False,
                'encoder_ready':encoder_ready,'available':False,'preview':None,'source_error':''}
        if final:
            try:
                audio_export.validate_script(final)
                result['script_ready']=mode=='provided' or not needs_upgrade
            except ValueError as error:result['source_error']=str(error)
        audio_name,meta_name,csv_name=audio_export.output_names(config['scope_minutes'])
        path=folder/'exports'/meta_name
        if result['script_ready'] and path.exists() and (folder/'exports'/audio_name).exists():
            record=read(path)
            if record.get('signature')==audio_export.signature(final,config,speakers):
                result.update(available=True,seconds=record['seconds'],signature=record['signature'],filename=audio_name,
                    report_file=csv_name,warnings=record.get('warnings',[]),scope_minutes=config['scope_minutes'])
        preview=folder/'audio_cache/apercu.json'
        if preview.exists() and (folder/'audio_cache/apercu.mp3').exists():
            record=read(preview)
            if record.get('settings_hash')==fingerprint(audio_export.settings(config,speakers)):result['preview']=record
        return result

    def archive_audio(self,folder):
        files=[p for p in (folder/'exports').glob('*') if p.name in ('podcast.mp3','audio.json','rapport_audio.csv') or p.name.startswith(('essai-','rapport_essai-'))]
        if not files and not (folder/'lecture/dialogue.json').exists():return
        archive=folder/'versions'/('audio-'+uuid.uuid4().hex[:12]);archive.mkdir(parents=True)
        for path in files:audio_export.replace(path,archive/path.name)
        source=folder/'lecture/dialogue.json'
        if source.exists():write(archive/'dialogue_audio.json',read(source))

    def save_audio_settings(self,folder,body):
        with self.lock:
            self.idle(folder);meta=read(folder/'projet.json')
            config=audio_export.settings(body)
            previous=audio_export.settings(meta.get('audio_settings',{}))
            if {k:v for k,v in config.items() if k!='scope_minutes'}!={k:v for k,v in previous.items() if k!='scope_minutes'}:
                self.archive_audio(folder)
            meta['audio_settings']=config;write(folder/'projet.json',meta)
            return {'saved':True}

    def audio_text(self,folder):
        path=folder/'lecture/dialogue.json'
        value=read(path) if path.exists() else {}
        meta=read(folder/'projet.json')
        return {'text':value.get('source_text',''),'mode':meta.get('audio_source_mode','project')}

    def save_audio_text(self,folder,body):
        with self.lock:
            self.idle(folder);meta=read(folder/'projet.json');mode=body.get('mode')
            if mode not in ('project','provided'):raise ValueError('Source audio inconnue.')
            parsed=voice_legacy.parse_dialogue(body.get('text','')) if mode=='provided' else None
            existing=folder/'lecture/dialogue.json'
            changed=mode!=meta.get('audio_source_mode','project') or (parsed and (not existing.exists() or parsed['input_hash']!=read(existing).get('input_hash')))
            if changed:self.archive_audio(folder)
            if parsed:write(existing,parsed)
            meta['audio_source_mode']=mode;write(folder/'projet.json',meta)
            return {'saved':True,'speakers':parsed['speakers'] if parsed else meta['settings']['speakers']}

    def import_audio_settings(self,folder,body):
        with self.lock:
            self.idle(folder)
            config=audio_export.settings(voice_legacy.read_settings(body.get('source','')))
            apply_cast=body.get('apply_cast',True)
            if type(apply_cast) is not bool:raise ValueError('Option de reprise des intervenantes invalide.')
            meta=read(folder/'projet.json');first=None
            if meta.get('audio_source_mode','project')=='project' and apply_cast:
                first=self.update_settings(folder,{**meta['settings'],'speakers':['AnneSo','Sophie']})['invalidated_from']
            elif meta.get('audio_source_mode','project')=='project':
                # La même répartition des rôles, en conservant les noms choisis.
                config['voices']={name:voice for name,voice in zip(meta['settings']['speakers'],config['voices'].values())}
            self.save_audio_settings(folder,config)
            return {'imported':True,'invalidated_from':first,'names':list(config['voices'])}

    def enqueue_audio(self,folder,body):
        with self.lock:
            self.idle(folder)
            action=body.get('action','generate')
            if action not in ('generate','preview','prepare'):raise ValueError('Commande audio inconnue.')
            if action=='prepare':
                try:audio_export.encoder()
                except ValueError:
                    if body.get('allow_download') is not True:
                        raise DownloadConsentRequired('Autorisation requise : télécharger imageio-ffmpeg 0.6.0 depuis PyPI et files.pythonhosted.org pour encoder le MP3. Aucun PDF ni dialogue n’est envoyé.')
            meta=read(folder/'projet.json');value,speakers,mode=self.audio_input(folder,meta)
            if action=='generate':
                if mode=='project' and Reviews(folder).pending():raise ValueError('Terminez les vérifications des sources avant de générer l’audio du projet.')
                if not value:raise ValueError('Terminez le script ou enregistrez un dialogue TXT avant de générer le MP3.')
                audio_export.validate_script(value)
                if mode=='project' and (folder/'etapes/02.json').exists() and read(folder/'etapes/02.json')['data'].get('quality_version')!=pipeline_module.SUMMARY_QUALITY_MODE:
                    raise ValueError('Réexaminez les sources du script avant sa lecture audio.')
                config=audio_export.settings(meta.get('audio_settings',{}));_,record_name,_=audio_export.output_names(config['scope_minutes'])
                record=folder/'exports'/record_name
                if record.exists() and read(record).get('version')!=audio_export.VERSION:self.archive_audio(folder)
            speaker=body.get('speaker')
            if action=='preview' and speaker not in speakers:raise ValueError('Choisissez un intervenant pour écouter sa voix.')
            task={'id':uuid.uuid4().hex,'kind':'audio','action':action,'speaker':speaker,'state':'queued',
                  'allow_download':body.get('allow_download') is True,
                  'queued_at':time.time(),'message':'Audio en attente','error':None,'app_version':APP_VERSION}
            cancel=threading.Event();self.cancels[task['id']]=cancel
            write(folder/'tache.json',task);self.task_errors.pop(folder.name,None)
            self.pending.put((folder,task,cancel));return task

    def state(self):
        with self.lock:
            projects = [self.summary(p) for p in self.projects.iterdir() if p.is_dir() and re.fullmatch('[a-f0-9]{32}',p.name)]
            return {'token':self.token,'defaults':defaults(),'steps':STEPS,'runtime':self.runtime,
                    'projects':sorted(projects,key=lambda p:p['created'],reverse=True)}

    def enqueue(self, folder, body):
        with self.lock:
            if self.runtime['page_sources']!='pdf-page-v1':
                raise ValueError('Mise à jour incomplète : pipeline.py est encore ancien. Fermez le programme et utilisez Mettre-a-jour.cmd dans le correctif.')
            if self.runtime['summary_quality']!='source-review-v5':
                raise ValueError('Mise à jour incomplète : les contrôles de synthèse sont absents. Fermez le programme et utilisez le nouveau correctif.')
            if self.runtime['editorial_mode']!='grounded-editorial-v3':
                raise ValueError('Mise à jour incomplète : les réponses reliées aux sources sont absentes. Réappliquer le correctif complet.')
            self.idle(folder)
            meta = read(folder/'projet.json')
            if not meta['pdfs']:
                raise ValueError('Ajoutez au moins un PDF.')
            first, until = body.get('first',1), body.get('until',9)
            if type(first) is not int or type(until) is not int or not 1<=first<=until<=9:
                raise ValueError('Étapes invalides.')
            if Reviews(folder).pending():
                raise ValueError('Traitez les vérifications regroupées ou choisissez « Réessayer avec le modèle » avant de continuer.')
            if first>1 and not (folder/'etapes'/f'{first-1:02}.json').exists():
                raise ValueError('L’étape précédente doit être terminée.')
            if first>2 and (folder/'etapes/02.json').exists() and source_review.diagnostic(read(folder/'etapes/02.json')['data'])['empty']:
                raise ValueError(source_review.empty_message(read(folder/'etapes/02.json')['data']))
            regenerate,refine = body.get('regenerate',False),body.get('refine',False)
            if type(regenerate) is not bool or type(refine) is not bool:
                raise ValueError('Option de régénération invalide.')
            if refine:
                if first!=2 or until!=2 or regenerate or not (folder/'etapes'/'02.json').exists():
                    raise ValueError('L’amélioration réutilise une étape 2 terminée, sans régénération forcée.')
                # Copie privée de l'extraction AVANT l'archivage des résultats.
                self.preserve_summaries(folder,meta)
            elif first>2 and (folder/'etapes/02.json').exists() and read(folder/'etapes/02.json')['data'].get('quality_version')!='source-review-v5':
                raise ValueError('Ce projet utilise les anciens contrôles. Cliquer sur Améliorer les résumés existants : les résultats seront archivés et les sources réexaminées avant la reconstruction du plan et du dialogue.')
            task = {'id':uuid.uuid4().hex,'first':first,'until':until,'state':'queued',
                    'queued_at':time.time(),'message':'En attente','error':None,'regenerate':regenerate,'refine':refine,'app_version':APP_VERSION}
            cancel = threading.Event();self.cancels[task['id']] = cancel
            write(folder/'tache.json',task)
            self.task_errors.pop(folder.name,None)
            self.pending.put((folder,task,cancel))
            return task

    def _loop(self):
        while not self.stop.is_set():
            try:
                folder,task,cancel = self.pending.get(timeout=.2)
            except queue.Empty:
                continue
            client = None
            try:
                if cancel.is_set():
                    raise Cancelled()
                meta = read(folder/'projet.json')
                if task.get('regenerate'):
                    meta['cache_generation'] = uuid.uuid4().hex
                    write(folder/'projet.json',meta)
                config = {**meta['settings'],'_generation':meta.get('cache_generation','initial')}
                if any(i['status']=='retry' for i in Reviews(folder).data()['items']):
                    config['_review_retry']=task['id']
                source_totals={}
                def progress(message):
                    task['message'] = message
                    task['updated_at']=time.time()
                    if message.startswith('Partie enregistrée en Markdown'):
                        task['last_saved_at']=task['updated_at']
                    page=re.match(r'(PDF\d+) — partie (\d+), page (\d+), fragment (\d+)',message)
                    if page:
                        if page[1] not in source_totals and (folder/'etapes/01.json').exists():
                            source_totals.update({d['id']:d.get('page_count') for d in read(folder/'etapes/01.json')['data']['documents']})
                        task['source_progress']={'document':page[1],'part':int(page[2]),'page':int(page[3]),'page_count':source_totals.get(page[1])}
                    match=re.match(r'Étape (\d+)/9',message)
                    if match:task['step']=int(match.group(1))
                    write(folder/'tache.json',task)
                task.update(state='running',started_at=time.time());progress('Préparation du traitement')
                if task.get('kind')=='pdf_reading':
                    index=int(task['document'][3:])-1;pdf=folder/'sources'/meta['pdfs'][index]['file']
                    pdf_reread.run(pdf,task['page'],folder/'lectures_pdf'/f'{task["document"]}-p{task["page"]}.md',cancel,progress)
                    task.update(state='needs_review',message='Relecture locale enregistrée : comparez-la visuellement avec le PDF.',error=None)
                    continue
                if task.get('kind')=='audio':
                    audio_input,audio_speakers,_=self.audio_input(folder,meta)
                    client=audio_export.AudioRenderer(folder,meta.get('audio_settings',{}),audio_speakers,cancel,progress)
                    self.active=(task['id'],client)
                    if task['action']=='prepare':audio_export.prepare_encoder(cancel,progress,allow_download=task.get('allow_download',False))
                    elif task['action']=='preview':client.preview(task['speaker'])
                    else:client.render(audio_input)
                    task.update(state='done',message='Moteur MP3 prêt' if task['action']=='prepare' else 'Aperçu vocal prêt' if task['action']=='preview' else 'Podcast MP3 prêt à écouter et télécharger')
                    continue
                # Une simple reprise conserve les parties finies dans l'étape en cours.
                # Leurs empreintes contrôlent les paramètres et données d'origine.
                invalidate(folder,task['first'],partials=task['regenerate'] or task.get('refine',False))
                client = self.client_factory(config,folder/'cache',cancel,progress)
                self.active = (task['id'],client)
                Pipeline(folder,client,cancel,progress).run(task['first'],task['until'])
                task.update(state='done',message='Étapes terminées et enregistrées')
                if task['until']==2 and source_review.diagnostic(read(folder/'etapes/02.json')['data'])['empty']:
                    task.update(state='needs_review',message='Rapport enregistré — aucune idée confirmée ; consulter les motifs et réexaminer l’étape 2')
            except Cancelled:
                task.update(state='cancelled',message='Annulé. Les répliques audio terminées sont conservées pour la reprise.' if task.get('kind')=='audio' else 'Annulé. Les parties Markdown terminées et les réponses en cache sont conservées.')
            except ReviewRequired as error:
                task.update(state='needs_review',message=str(error),error=None,step=error.step)
            except Exception as error:
                task.update(state='error',message='Traitement arrêté',error=str(error)[-5000:])
            finally:
                self.active = None
                task['finished_at']=time.time()
                try:
                    write(folder/'tache.json',task)
                except OSError as error:
                    # Une erreur persistante de fichier ne doit pas tuer le worker
                    # ni laisser l'interface afficher « en cours » indéfiniment.
                    failed = {**task,'state':'error','message':'Enregistrement de l’avancement impossible',
                              'error':'Le fichier tache.json reste inaccessible. Fermez les autres fenêtres du programme, puis relancez. Détail : '+str(error)}
                    with self.lock:
                        self.task_errors[folder.name]=failed
                finally:
                    self.cancels.pop(task['id'],None)
                    self.pending.task_done()

    def cancel(self, folder):
        task = read(folder/'tache.json')
        event = self.cancels.get(task['id'])
        if event:
            event.set()
            if self.active and self.active[0]==task['id']:
                self.active[1].cancel()
        return {'cancel_requested':bool(event)}

    def update_settings(self, folder, body):
        with self.lock:
            self.idle(folder)
            meta = read(folder/'projet.json')
            new = settings(body)
            changed = {k for k in new if new[k]!=meta['settings'][k]}
            first = 10
            for key in changed:
                first = min(first,8 if key=='speakers' else 5 if key=='minutes' else 4 if key=='audience' else 2)
            if first<=9:
                if first==2:self.preserve_summaries(folder,meta)
                invalidate(folder,first)
                meta['settings']=new
                write(folder/'projet.json',meta)
            return {'invalidated_from':first if first<=9 else None}

    def preserve_summaries(self, folder, meta):
        if (folder/'etapes/01.json').exists() and (folder/'etapes/02.json').exists():
            write(folder/'reprises/02.json',{'source':fingerprint(read(folder/'etapes/01.json')['data']),
                  'generation':meta.get('cache_generation','initial'),'data':read(folder/'etapes/02.json')['data']})

    def close(self):
        self.stop.set()
        for event in list(self.cancels.values()):event.set()
        if self.active:
            self.active[1].cancel()
        self.worker.join(timeout=5)


class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,address,app):
        self.app=app
        super().__init__(address,Handler)


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*_):
        pass

    @property
    def app(self):
        return self.server.app

    def respond(self,status,raw,mime='application/json; charset=utf-8',extra=()):
        self.send_response(status)
        self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.send_header('Referrer-Policy','no-referrer')
        for key,value in extra:self.send_header(key,value)
        self.end_headers();self.wfile.write(raw)

    def json(self,value,status=200):
        self.respond(status,json.dumps(value,ensure_ascii=False,allow_nan=False).encode())

    def authorized(self,write_request=False):
        port=self.server.server_port
        if self.headers.get('Host') not in (f'127.0.0.1:{port}',f'localhost:{port}'):
            self.json({'error':'Adresse locale invalide.'},403);return False
        origin=self.headers.get('Origin')
        if origin and origin not in (f'http://127.0.0.1:{port}',f'http://localhost:{port}'):
            self.json({'error':'Origine non autorisée.'},403);return False
        if write_request and not hmac.compare_digest(self.headers.get('X-Podcast-Token',''),self.app.token):
            self.json({'error':'Rechargez la page pour continuer.'},403);return False
        return True

    def size(self,maximum):
        if self.headers.get('Transfer-Encoding'):
            raise ValueError('Content-Length requis.')
        size=int(self.headers.get('Content-Length','-1'))
        if not 0<=size<=maximum:
            raise ValueError('Taille de requête invalide ou trop importante.')
        return size

    def body(self):
        if self.headers.get('Content-Type','').split(';')[0]!='application/json':
            raise ValueError('Requête JSON requise.')
        value=json.loads(self.rfile.read(self.size(1024*1024)))
        if not isinstance(value,dict):raise ValueError('Objet JSON requis.')
        return value

    def do_GET(self):
        if not self.authorized():return
        try:
            path=urlsplit(self.path).path
            if path=='/api/state':self.json(self.app.state());return
            static={'/':('index.html','text/html; charset=utf-8'),'/app.js':('app.js','text/javascript; charset=utf-8'),'/reviews.js':('reviews.js','text/javascript; charset=utf-8'),'/style.css':('style.css','text/css; charset=utf-8')}
            if path in static:
                name,mime=static[path];self.respond(200,(ROOT/'web'/name).read_bytes(),mime);return
            parts=path.split('/')
            if len(parts)==5 and parts[1:3]==['api','projects'] and parts[4]=='audio-text':
                self.json(self.app.audio_text(self.app.project(parts[3])));return
            if len(parts)==4 and parts[1]=='sources':
                folder=self.app.project(parts[2]);match=re.fullmatch(r'PDF([1-9]\d*)\.pdf',parts[3])
                if not match:raise FileNotFoundError('PDF inconnu.')
                sources=read(folder/'projet.json')['pdfs'];index=int(match[1])-1
                if index>=len(sources):raise FileNotFoundError('PDF inconnu.')
                file=(folder/'sources'/sources[index]['file']).resolve()
                if file.parent!=(folder/'sources').resolve():raise FileNotFoundError('PDF invalide.')
                self.send_media(file,'application/pdf');return
            if len(parts)==4 and parts[1]=='media':
                folder=self.app.project(parts[2]);name=parts[3]
                state=self.app.summary(folder)['audio']
                if name==state.get('filename') and state['available']:file=folder/'exports'/name
                elif name=='apercu.mp3' and state['preview']:file=folder/'audio_cache/apercu.mp3'
                else:raise FileNotFoundError('Audio non disponible pour ce script et ces voix.')
                self.send_media(file);return
            if len(parts)==6 and parts[1:3]==['api','projects'] and parts[4]=='stages':
                folder=self.app.project(parts[3]);number=int(parts[5])
                if not 1<=number<=9:raise ValueError('Étape invalide.')
                if number==2 and parse_qs(urlsplit(self.path).query).get('view')==['summary']:
                    data=read(folder/'etapes/02.json')['data']
                    summaries=[]
                    blocks=['# Résumé de l’étape 2','Le registre complet et les motifs détaillés sont disponibles dans les fichiers à télécharger.']
                    for doc in data['documents']:
                        for part in doc['parts']:
                            summaries.append({'document':doc['id'],'number':part['number'],'summary':part['summary'],
                                'retained':len(part['ideas']),'unconfirmed':len(part.get('uncertain_ideas',[]))})
                            blocks.append('## '+doc['id']+' — partie '+str(part['number'])+'\n\n'+
                                str(len(part['ideas']))+' idées retenues · '+str(len(part.get('uncertain_ideas',[])))+' à examiner\n\n'+part['summary'])
                    self.json({'markdown':'\n\n'.join(blocks),'parts':summaries});return
                self.json({'markdown':(folder/'etapes'/f'{number:02}.md').read_text(encoding='utf-8')});return
            if len(parts)==4 and parts[1]=='files':
                folder=self.app.project(parts[2]);name=parts[3]
                if re.fullmatch(r'0[1-9]\.(md|json)',name):file=folder/'etapes'/name
                elif re.fullmatch(r'partie-0[1-9]-[A-Za-z0-9-]+\.md',name):
                    file=folder/'etapes'/'parties'/name.removeprefix('partie-')
                    if not file.with_suffix('.json').exists():raise FileNotFoundError('Partie non terminée.')
                elif re.fullmatch(r'lecture-PDF[1-9]\d*-p[1-9]\d*\.md',name):
                    file=folder/'lectures_pdf'/name.removeprefix('lecture-')
                    record=read(file.with_suffix('.json'));index=int(name.split('-')[1][3:])-1
                    sources=read(folder/'projet.json')['pdfs']
                    if index>=len(sources) or sources[index].get('sha256')!=record['sha256']:raise FileNotFoundError('Cette lecture ne correspond plus au PDF actuel.')
                elif name in ('podcast.md','podcast.txt','podcast.json'):
                    if name not in self.app.summary(folder)['exports']:raise FileNotFoundError('Le script attend la résolution des vérifications ou la reprise des étapes.')
                    file=folder/'exports'/name
                elif name in ('podcast.mp3','essai-3min.mp3','essai-5min.mp3','rapport_audio.csv','rapport_essai-3min.csv','rapport_essai-5min.csv'):
                    audio=self.app.summary(folder)['audio']
                    if not audio['available'] or name not in (audio['filename'],audio['report_file']):raise FileNotFoundError('Ce résultat audio ne correspond pas à la sélection actuelle.')
                    file=folder/'exports'/name
                elif name=='dossier.zip':
                    self.app.idle(folder)
                    file=folder/'dossier.zip'
                    with zipfile.ZipFile(file,'w',zipfile.ZIP_DEFLATED) as archive:
                        archive.write(folder/'projet.json','projet.json')
                        for name in ('verifications.json','corrections.json'):
                            if (folder/name).exists():archive.write(folder/name,name)
                        for sub in ('sources','etapes','memoire','exports','reprises','lecture','lectures_pdf'):
                            for f in (folder/sub).rglob('*'):
                                if f.is_file():archive.write(f,f.relative_to(folder))
                else:raise FileNotFoundError('Fichier inconnu.')
                self.send_file(file);return
            raise FileNotFoundError('Page introuvable.')
        except (BrokenPipeError,ConnectionResetError):pass
        except Busy as error:self.json({'error':str(error)},409)
        except (ValueError,OSError) as error:self.json({'error':str(error)},404)

    def send_file(self,path):
        if not path.is_file():raise FileNotFoundError('Le résultat n’est pas encore disponible.')
        mime='audio/mpeg' if path.suffix=='.mp3' else 'text/csv; charset=utf-8' if path.suffix=='.csv' else 'application/zip' if path.suffix=='.zip' else 'application/json' if path.suffix=='.json' else 'text/plain; charset=utf-8'
        self.send_response(200);self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(path.stat().st_size))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Disposition',f'attachment; filename="{path.name}"')
        self.end_headers()
        with path.open('rb') as f:
            while chunk:=f.read(256*1024):self.wfile.write(chunk)

    def send_media(self,path,mime='audio/mpeg'):
        total=path.stat().st_size;start=0;end=total-1;status=200
        header=self.headers.get('Range')
        if header:
            match=re.fullmatch(r'bytes=(\d*)-(\d*)',header)
            try:
                if not match or not any(match.groups()):raise ValueError()
                if match[1]:start=int(match[1]);end=min(end,int(match[2])) if match[2] else end
                else:start=max(0,total-int(match[2]))
                if start>end or start>=total:raise ValueError()
            except ValueError:
                self.respond(416,b'',mime,[('Content-Range','bytes */'+str(total))]);return
            status=206
        self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Accept-Ranges','bytes')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(end-start+1))
        if status==206:self.send_header('Content-Range',f'bytes {start}-{end}/{total}')
        self.end_headers()
        with path.open('rb') as f:
            f.seek(start);remaining=end-start+1
            while remaining:
                chunk=f.read(min(256*1024,remaining))
                if not chunk:break
                self.wfile.write(chunk);remaining-=len(chunk)

    def do_POST(self):
        if not self.authorized(True):return
        try:
            self.connection.settimeout(120)
            path=urlsplit(self.path).path
            if path=='/api/models':self.json({'models':models(self.body().get('endpoint',defaults()['endpoint']))});return
            if path=='/api/voices':self.json({'voices':audio_export.VoiceStudio(audio_export.settings(self.body())).voices()});return
            if path=='/api/projects':self.json(self.app.create(self.body()),201);return
            parts=path.split('/')
            if len(parts)!=5 or parts[1:3]!=['api','projects']:raise FileNotFoundError('Commande inconnue.')
            folder=self.app.project(parts[3]);action=parts[4]
            if action=='pdf':self.upload(folder);return
            body=self.body()
            if action=='run':self.json(self.app.enqueue(folder,body),202)
            elif action=='cancel':self.json(self.app.cancel(folder))
            elif action=='settings':self.json(self.app.update_settings(folder,body))
            elif action=='review':self.json(self.app.resolve_review(folder,body))
            elif action=='defer-reviews':self.json(self.app.defer_reviews(folder,body))
            elif action=='reopen-review':self.json(self.app.reopen_review(folder,body))
            elif action=='flag-source':self.json(self.app.flag_source(folder,body))
            elif action=='reread':self.json(self.app.enqueue_reread(folder,body),202)
            elif action=='audio-text':self.json(self.app.save_audio_text(folder,body))
            elif action=='audio-import':self.json(self.app.import_audio_settings(folder,body))
            elif action=='audio-settings':self.json(self.app.save_audio_settings(folder,body))
            elif action=='audio':self.json(self.app.enqueue_audio(folder,body),202)
            else:raise FileNotFoundError('Commande inconnue.')
        except (BrokenPipeError,ConnectionResetError):pass
        except Busy as error:self.json({'error':str(error)},409)
        except FileNotFoundError as error:self.json({'error':str(error)},404)
        except (ValueError,KeyError,TypeError) as error:self.json({'error':str(error)},400)
        except (OSError,RuntimeError) as error:self.json({'error':str(error)},502)

    def upload(self,folder):
        with self.app.lock:
            self.app.idle(folder)
            if any((folder/'etapes').glob('*.json')):raise Busy('Créez un nouveau projet pour changer les PDF après le début du traitement.')
            size=self.size(100*1024**2)
            if size<5:raise ValueError('Le PDF est vide ou invalide.')
            name=unquote(self.headers.get('X-Filename','document.pdf')).replace('\\','/').split('/')[-1][:200]
            if not name.lower().endswith('.pdf'):raise ValueError('Choisissez un fichier PDF.')
            target=folder/'sources'/(uuid.uuid4().hex+'.pdf')
            digest=hashlib.sha256()
            try:
                with target.open('wb') as f:
                    first=self.rfile.read(5)
                    if first!=b'%PDF-':raise ValueError('Le fichier ne possède pas un en-tête PDF valide.')
                    f.write(first);digest.update(first);remaining=size-5
                    while remaining:
                        data=self.rfile.read(min(1024**2,remaining))
                        if not data:raise ValueError('Copie du PDF interrompue.')
                        f.write(data);digest.update(data);remaining-=len(data)
                meta=read(folder/'projet.json')
                if len(meta['pdfs'])>=30:raise ValueError('Maximum de 30 PDF par projet.')
                if any(p['sha256']==digest.hexdigest() for p in meta['pdfs']):raise ValueError('Ce PDF est déjà présent dans le projet.')
                meta['pdfs'].append({'file':target.name,'name':name,'sha256':digest.hexdigest(),'bytes':size})
                write(folder/'projet.json',meta)
            except Exception:
                target.unlink(missing_ok=True);raise
            self.json({'uploaded':size})


def main():
    parser=argparse.ArgumentParser(description='Podcast pédagogique local à partir de PDF')
    parser.add_argument('--data',type=Path,default=ROOT/'donnees')
    parser.add_argument('--port',type=int,default=8766)
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args();app=App(args.data)
    def interrupt(*_):raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM,interrupt)
    try:
        try:server=Server(('127.0.0.1',args.port),app)
        except OSError:server=Server(('127.0.0.1',0),app)
        url=f'http://127.0.0.1:{server.server_port}/'
        print('Podcast pédagogique : '+url,flush=True)
        print('Gardez cette fenêtre ouverte. Ctrl+C pour arrêter.',flush=True)
        if not args.no_browser:webbrowser.open(url)
        try:server.serve_forever(poll_interval=.2)
        except KeyboardInterrupt:pass
        finally:server.server_close()
    finally:app.close()


if __name__=='__main__':main()
